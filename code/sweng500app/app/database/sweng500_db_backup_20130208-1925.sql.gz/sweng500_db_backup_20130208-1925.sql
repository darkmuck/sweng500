-- phpMyAdmin SQL Dump
-- version 3.5.2.2
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Feb 09, 2013 at 01:24 AM
-- Server version: 5.5.27
-- PHP Version: 5.4.7

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT=0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `sweng500`
--
CREATE DATABASE `sweng500` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `sweng500`;

-- --------------------------------------------------------

--
-- Table structure for table `permissions`
--

CREATE TABLE IF NOT EXISTS `permissions` (
  `id` int(8) NOT NULL AUTO_INCREMENT,
  `permission_name` varchar(100) NOT NULL,
  `created` datetime DEFAULT NULL,
  `modified` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `permissions`
--

INSERT INTO `permissions` (`id`, `permission_name`, `created`, `modified`) VALUES
(1, '*', '2013-02-08 15:07:34', '2013-02-08 15:07:34');

-- --------------------------------------------------------

--
-- Table structure for table `types`
--

CREATE TABLE IF NOT EXISTS `types` (
  `id` int(8) NOT NULL AUTO_INCREMENT,
  `type_name` varchar(25) NOT NULL,
  `created` datetime DEFAULT NULL,
  `modified` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `types`
--

INSERT INTO `types` (`id`, `type_name`, `created`, `modified`) VALUES
(1, 'Administrator', '2013-02-08 15:03:17', '2013-02-08 15:03:17'),
(2, 'Instructor', '2013-02-08 15:03:17', '2013-02-08 15:03:17'),
(3, 'Student', '2013-02-08 15:03:17', '2013-02-08 15:03:17');

-- --------------------------------------------------------

--
-- Table structure for table `types_permissions`
--

CREATE TABLE IF NOT EXISTS `types_permissions` (
  `id` int(8) NOT NULL AUTO_INCREMENT,
  `type_id` int(8) NOT NULL,
  `permission_id` int(8) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `type_id` (`type_id`),
  KEY `permission_id` (`permission_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- RELATIONS FOR TABLE `types_permissions`:
--   `type_id`
--       `types` -> `id`
--   `permission_id`
--       `permissions` -> `id`
--

--
-- Dumping data for table `types_permissions`
--

INSERT INTO `types_permissions` (`id`, `type_id`, `permission_id`) VALUES
(1, 1, 1);

-- --------------------------------------------------------

--
-- Table structure for table `types_users`
--

CREATE TABLE IF NOT EXISTS `types_users` (
  `id` int(8) NOT NULL AUTO_INCREMENT,
  `type_id` int(8) NOT NULL,
  `user_id` int(8) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `type_id` (`type_id`),
  KEY `user_id` (`user_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- RELATIONS FOR TABLE `types_users`:
--   `type_id`
--       `types` -> `id`
--   `user_id`
--       `users` -> `id`
--

--
-- Dumping data for table `types_users`
--

INSERT INTO `types_users` (`id`, `type_id`, `user_id`) VALUES
(1, 1, 1);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE IF NOT EXISTS `users` (
  `id` int(8) NOT NULL AUTO_INCREMENT,
  `username` varchar(15) NOT NULL,
  `password` varchar(40) NOT NULL,
  `enabled` tinyint(1) DEFAULT '1',
  `type_id` int(8) DEFAULT NULL,
  `last_name` varchar(50) NOT NULL,
  `middle_name` varchar(50) DEFAULT NULL,
  `first_name` varchar(50) NOT NULL,
  `created` datetime DEFAULT NULL,
  `modified` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `type_id` (`type_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- RELATIONS FOR TABLE `users`:
--   `type_id`
--       `types` -> `id`
--

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `password`, `enabled`, `type_id`, `last_name`, `middle_name`, `first_name`, `created`, `modified`) VALUES
(1, 'tester', 'b96689421b87d4c93f377eba19b8eb97807e2656', 1, 1, 'Tester', 'Tester', 'Tester', '2013-02-08 15:03:41', '2013-02-08 15:03:41');

--
-- Constraints for dumped tables
--

--
-- Constraints for table `types_permissions`
--
ALTER TABLE `types_permissions`
  ADD CONSTRAINT `types_permissions_ibfk_1` FOREIGN KEY (`type_id`) REFERENCES `types` (`id`),
  ADD CONSTRAINT `types_permissions_ibfk_2` FOREIGN KEY (`permission_id`) REFERENCES `permissions` (`id`);

--
-- Constraints for table `types_users`
--
ALTER TABLE `types_users`
  ADD CONSTRAINT `types_users_ibfk_1` FOREIGN KEY (`type_id`) REFERENCES `types` (`id`),
  ADD CONSTRAINT `types_users_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`);

--
-- Constraints for table `users`
--
ALTER TABLE `users`
  ADD CONSTRAINT `users_ibfk_1` FOREIGN KEY (`type_id`) REFERENCES `types` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
